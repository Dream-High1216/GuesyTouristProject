﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GuestyV_01.Areas.Identity.Data
{
    public class UserRoleRepository
    {
        public IEnumerable<SelectListItem> UserRoleList
        {
            get
            {
                return new List<SelectListItem>
                    {
                        new SelectListItem { Text = "--- Select User Role ---" , Value = null},
                        new SelectListItem { Text = "Owner", Value = "Owner"},
                        new SelectListItem { Text = "Manager", Value = "Manager"},
                        new SelectListItem { Text = "Team", Value = "Team"},
                        new SelectListItem { Text = "Partner", Value = "Partner"}
                    };
            }
        }
    }
}
