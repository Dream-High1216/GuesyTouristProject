﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GuestyV_01.Models
{
    public class UserRoleType
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
